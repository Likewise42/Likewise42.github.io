using UnityEngine;
using System.Collections;

//use the Generic system here to make use of a Flocker list later on
using System.Collections.Generic;

[RequireComponent(typeof(CharacterController))]

abstract public class Vehicle : MonoBehaviour {

    //-----------------------------------------------------------------------
    // Class Fields
    //-----------------------------------------------------------------------

    //movement
    protected Vector3 acceleration;
    protected Vector3 velocity;
    protected Vector3 desired;

    public Vector3 Velocity {
        get { return velocity; }
    }

    //public for changing in Inspector
    //define movement behaviors
    public float maxSpeed = 6.0f;
    public float maxForce = 12.0f;
    public float mass = 1.0f;
    public float radius = 1.0f;
    public float sepDist = 5.0f;
    public float cohDist = 20f;
	public float arriveDist = 10f;
	public float leaderDist = 5f;
	public float leaderFollowDist = 7.5f;
	public float copSight = 20f;
	public float copDestroyRad = 3f;

    //access to Character Controller component
    CharacterController charControl;
    
	//acces the game manager
	protected GameManager gm;

    abstract protected void CalcSteeringForces();

	//obstacle avoid floats
	public float safeDistance = 10f;

    //WEIGHTING!!!!
	public float avoidWeight = 100f;
    public float sepWeight = 10000000f;
    public float alignmentWeight = 100f;
    public float cohesionWeight = 100f;
    public float seekWeight = 75.0f;
	public float fleeWeight = 75.0f;
	public float arriveWeight = 100f;
	public float leaderWeight = 100f;

    //-----------------------------------------------------------------------
    // Start and Update
    //-----------------------------------------------------------------------
	virtual public void Start(){
        //acceleration = new Vector3 (0, 0, 0);     
        acceleration = Vector3.zero;
        velocity = transform.forward;
        charControl = GetComponent<CharacterController>();

		gm = GameObject.Find ("GameManagerGO").GetComponent<GameManager> ();
	}

	
	// Update is called once per frame
	protected void Update () {
		CalcSteeringForces ();

		//add acceleration
		velocity += acceleration * Time.deltaTime;
		velocity.y = 0;

		//limit speed
		velocity = Vector3.ClampMagnitude (velocity, maxSpeed);

		//orients guy
		transform.forward = velocity.normalized;
		
		//apply movement
		charControl.Move (velocity * Time.deltaTime);

		//reset
		acceleration = Vector3.zero;
	}


    //-----------------------------------------------------------------------
    // Class Methods
    //-----------------------------------------------------------------------

    protected void ApplyForce(Vector3 steeringForce) {
        acceleration += steeringForce / mass;
    }

    protected Vector3 Seek(Vector3 targetPos) {
        desired = targetPos - transform.position;
        desired = desired.normalized * maxSpeed;
        desired -= velocity;
        desired.y = 0;
        return desired;
    }

	protected Vector3 Flee(Vector3 targetPos) {
		desired = targetPos - transform.position;
		desired = desired.normalized * maxSpeed;
		desired -= velocity;
		desired.y = 0;
		return -desired;
	}

	protected Vector3 AvoidObstacle(GameObject ob, float safe) 
	{
		desired = Vector3.zero;

		float obRad = ob.GetComponent<ObstacleScript> ().Radius;

		Vector3 vecToCenter = ob.transform.position - transform.position;

		vecToCenter.y = 0;

		if (vecToCenter.magnitude > safe) {
			return Vector3.zero;
		}

		if (Vector3.Dot (vecToCenter, transform.forward) < 0) {
			return Vector3.zero;
		}

		if (Mathf.Abs (Vector3.Dot (vecToCenter, transform.right)) > obRad + radius) {
			return Vector3.zero;
		}

		if (Vector3.Dot (vecToCenter, transform.right) < 0) {
			desired = transform.right * maxSpeed;
			Debug.DrawLine (transform.position, ob.transform.position, Color.red);
		} else {
			desired = transform.right * -maxSpeed;
			Debug.DrawLine (transform.position,ob.transform.position, Color.green);
		}

		return desired;
	}

    protected Vector3 Seperation()
    {
        //number of other flckers to avoid
        int numAvoid = 0;

        //vector between flocker i and this flocker
        Vector3 distVector;

        //distance between flocker i and this flocker
        float distNum;

        //vector to return
        Vector3 sepVector = Vector3.zero;

        for (int i = 0; i < gm.Flock.Count; i++)
        {
            distVector = transform.position- gm.Flock[i].transform.position;
            distNum = distVector.magnitude;

            if (distNum < sepDist)
            {
                numAvoid++;

                distVector.Normalize();

                sepVector += distVector;
                
            }
        }

        sepVector = sepVector / numAvoid;


        return sepVector;

    }

    protected Vector3 SeperationFollower()
    {
        //number of other flckers to avoid
        int numAvoid = 0;

        //vector between flocker i and this flocker
        Vector3 distVector;

        //distance between flocker i and this flocker
        float distNum;

        //vector to return
        Vector3 sepVector = Vector3.zero;

        for (int i = 0; i < gm.followers.Count; i++)
        {
            distVector = transform.position - gm.followers[i].transform.position;
            distNum = distVector.magnitude;

            if (distNum < sepDist)
            {
                numAvoid++;

                distVector.Normalize();

                sepVector += distVector;

            }
        }

        sepVector = sepVector / numAvoid;


        return sepVector;

    }

    protected Vector3 Alignment()
    {
        desired = gm.FlockDirection - transform.position;
        desired = desired.normalized * maxSpeed;
        desired -= velocity;
        desired.y = 0;
        return desired;
    }

	protected Vector3 AlignmentCop()
	{
		desired = gm.FlockDirection - transform.position;
		desired = desired.normalized * maxSpeed;
		desired -= velocity;
		desired.y = 0;
		return desired;
	}

    protected Vector3 Cohesion()
    {
        Vector3 distFromCent = gm.transform.position - transform.position;
        if (distFromCent.magnitude > cohDist)
        {
            return Seek(gm.transform.position);
        }
        return Vector3.zero;
    }

	protected Vector3 Arrival(Vector3 targetPos)
	{
		Vector3 target_offset = targetPos - transform.position;
		float distance = target_offset.magnitude;
		float ramped_speed = maxSpeed * (distance / arriveDist);
		if (ramped_speed > maxSpeed) {
			ramped_speed = maxSpeed;
		}
		Vector3 desired = (ramped_speed / distance) * target_offset;
		Vector3 steering = desired - velocity;
		return steering;
	}

	protected Vector3 LeaderFollowing(GameObject Leader)
	{
		Vector3 steer;
		Vector3 followPoint;

		Followers leaderFollow = Leader.GetComponent<Followers> ();


		followPoint = Leader.transform.position- Vector3.ClampMagnitude(leaderFollow.velocity,7);
		//followPoint = followPoint * 2;

		Debug.DrawLine (followPoint, Leader.transform.position, Color.red);

		float distance = Vector3.Distance(Leader.transform.position,transform.position);

		if (distance < leaderDist) {
			steer = Flee(Leader.transform.position);
		}

		else {
			steer = Arrival(followPoint);
		}

		return steer;
	}

}