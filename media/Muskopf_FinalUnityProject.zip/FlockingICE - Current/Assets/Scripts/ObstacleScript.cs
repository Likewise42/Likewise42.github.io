﻿using UnityEngine;
using System.Collections;

public class ObstacleScript : MonoBehaviour {

	public float radius = 2.4f;

	public float Radius {
		get { return radius; }
	}
	
}

	