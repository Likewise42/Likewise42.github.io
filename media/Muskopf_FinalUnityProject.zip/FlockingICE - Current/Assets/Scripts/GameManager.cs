﻿using UnityEngine;
using System.Collections;


//add using System.Collections.Generic; to use the generic list format
using System.Collections.Generic;

public class GameManager : MonoBehaviour {

    //-----------------------------------------------------------------------
    // Class Fields
    //-----------------------------------------------------------------------
    public GameObject dude;
    public GameObject target;
    public GameObject follow;

    public GameObject dudePrefab;
    public GameObject targetPrefab;
    public GameObject obstaclePrefab;
    public GameObject followerPrefab;
	public GameObject criminalPrefab;
    public float targDist = 4f;

    //array of Obstacles
    public GameObject[] obstacles;

	public GameObject[] Obstacles {
		get { return obstacles; }
	}

    //array of Nodes
    public GameObject[] nodes;

    public GameObject[] Nodes
    {
        get { return nodes; }
    }
	

    private GameObject[] tempFollowerArray;
    public List<GameObject> followers;
	public List<GameObject> criminals;
	public List<GameObject> copsAggro;

    //flocking things
    private Vector3 centroid;
	public Vector3 Centroid{
		get { return centroid;}
	}

	private Vector3 flockDirection;
	public Vector3 FlockDirection{
		get {return flockDirection;}
	}

	private Vector3 copFlockDirection;
	public Vector3 CopFlockDirection{
		get {return copFlockDirection;}
	}

	private List<GameObject> flock;
	public List<GameObject> Flock {
		get	{ return flock;}
	}

	public List<GameObject> houses;

	public int numberFlockers;
    public int numberObstacles;
    public int numberFollowers;

    public int spawnTime;
    public int spawnTimer;

    //-----------------------------------------------------------------------
    // Start and Update
    //-----------------------------------------------------------------------
	void Start () {

		//create flock
		flock = new List<GameObject> ();

        //Create the target (noodle)
        Vector3 pos = new Vector3(0, 4.0f, 0);
        target = (GameObject)Instantiate(targetPrefab, pos, Quaternion.identity);
        //target = Instantiate(targetPrefab, pos, Quaternion.identity) as GameObject;

		for (int i = 0; i < numberFlockers; i++) {
			pos = new Vector3(Random.Range(-5,5), 1, Random.Range(-5,5));
			dude = (GameObject)Instantiate(dudePrefab, pos, Quaternion.identity);
			dude.GetComponent<Seeker> ().seekerTarget = target;
			flock.Add(dude);
		}

		//instantiates obstacles
		for (int i = 0; i < numberObstacles; i++) {
			pos = new Vector3(Random.Range(-30,30),1.1f,Random.Range(-30,30));
			Quaternion rot = Quaternion.Euler(new Vector3(0,Random.Range(0,180),0));
			Instantiate(obstaclePrefab, pos, rot);
		}

		//adds obstacles to array
		obstacles = GameObject.FindGameObjectsWithTag ("Obstacle");

        //adds obstacles to array
        nodes = GameObject.FindGameObjectsWithTag("Node");

        //adds all followers to the list
        tempFollowerArray = GameObject.FindGameObjectsWithTag("Follower");
        foreach (GameObject g in tempFollowerArray)
        {
            followers.Add(g);
        }
        
            

        //set the camera's target 
        //Camera.main.GetComponent<SmoothFollow>().target = transform;
        
	}
	

	void Update () {
        NewFollowers();

		if (criminals.Count == 0) {
			copsAggro.Clear();
		}

        float dist = Vector3.Distance (target.transform.position, dude.transform.position);

		if (dist < targDist) {
			do{
			target.transform.position = new Vector3(Random.Range(-30,30), 4f, Random.Range (-30,30));
			}
			while (NearAnObstacle());
		}

		for (int i = 0; i < Flock.Count; i++) {
			dist = Vector3.Distance (target.transform.position, flock[i].transform.position);
			if (dist < targDist) {
				do{
					target.transform.position = new Vector3(Random.Range(-30,30), 4f, Random.Range (-30,30));
				}
				while (NearAnObstacle());
			}

            if (dist < targDist)
            {
                do
                {
                    target.transform.position = new Vector3(Random.Range(-30, 30), 4f, Random.Range(-30, 30));
                }
                while (NearAnObstacle());
            }
		}

        

        for (int i = 0; i < Flock.Count; i++)
        {
            flockDirection += Flock[i].transform.forward;
            centroid += Flock[i].transform.position;
        }
        flockDirection /= Flock.Count;
        centroid /= Flock.Count;

        transform.forward = flockDirection;
        transform.position = centroid;

		for (int i = 0; i < copsAggro.Count; i++)
		{
			copFlockDirection += copsAggro[i].transform.forward;
			centroid += copsAggro[i].transform.position;
		}
		copFlockDirection /= copsAggro.Count;
		centroid /= copsAggro.Count;
		
		transform.forward = copFlockDirection;
		transform.position = centroid;
	}

	bool NearAnObstacle()
	{

		//if the obstacle is withing 4 units of the noodle return true
		for (int i = 0; i < obstacles.Length; i++) {
			if (Vector3.Distance(target.transform.position,obstacles[i].transform.position) < 5f) {
				return true;
			}
		}

		//else false
		return false;
	}

    void NewFollowers()
    {
        if (followers.Count < numberFollowers)
        {
            spawnTimer++;
        }
        
        if ((followers.Count < numberFollowers) && spawnTimer > spawnTime)
        {
			float crime = Random.value;

			if (crime > .01 && criminals.Count < 1) {
				Vector3 pos = new Vector3(-73,1.7f,117);
				follow = (GameObject)Instantiate(criminalPrefab,pos,Quaternion.Euler(Vector3.zero));
				followers.Add(follow);
				criminals.Add(follow);
				spawnTimer = 0;
			}

			else {
				Vector3 pos = new Vector3(-73,1.7f,117);
				follow = (GameObject)Instantiate(followerPrefab,pos,Quaternion.Euler(Vector3.zero));
				followers.Add(follow);
				spawnTimer = 0;
			}
            
        }
    }

    //-----------------------------------------------------------------------
    // Flocking Methods
    //-----------------------------------------------------------------------



}
