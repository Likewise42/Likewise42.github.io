using UnityEngine;
using System.Collections;

//add using System.Collections.Generic; to use the generic list format
using System.Collections.Generic;

public class Seeker : Vehicle {

    //-----------------------------------------------------------------------
    // Class Fields
    //-----------------------------------------------------------------------
    public GameObject seekerTarget;

    //Seeker's steering force (will be added to acceleration)
    private Vector3 force;

    

    //-----------------------------------------------------------------------
    // Start - No Update
    //-----------------------------------------------------------------------
	// Call Inherited Start and then do our own
	override public void Start () {
        //call parent's start
		base.Start();

        //initialize
        force = Vector3.zero;
	}

    //-----------------------------------------------------------------------
    // Class Methods
    //-----------------------------------------------------------------------

    protected override void CalcSteeringForces() {
        //reset value to (0, 0, 0)
        force = Vector3.zero;

        //got a seeking force
        //force += Seek(seekerTarget.transform.position) * seekWeight;

        //limited the seeker's steering force
        force = Vector3.ClampMagnitude(force, maxForce);

		//calls and weights seek method
		force += Seek(seekerTarget.transform.position) * seekWeight;

		//avoid obstacles
		for (int i = 0; i < gm.Obstacles.Length; i++) {
			force += AvoidObstacle(gm.Obstacles[i], safeDistance) * avoidWeight;
		}

        //flockign methods
        force += Seperation() * sepWeight;

        force += Alignment() * alignmentWeight;

        force += Cohesion() * cohesionWeight;

		//limits force to max force
		force = Vector3.ClampMagnitude (force, maxForce);

        //applied the steering force to this Vehicle's acceleration (ApplyForce)
        ApplyForce(force);
    }

    
	

}
