﻿using UnityEngine;
using System.Collections;

//add using System.Collections.Generic; to use the generic list format
using System.Collections.Generic;

public class NodeScript : MonoBehaviour {

    public GameObject adjSpecial;
    public GameObject adjNode1, adjNode2, adjNode3, adjNode4;
    public List<GameObject> adjNodeList;

	// Use this for initialization
	void Start () {

        if (adjNode1 != null)
        {
            adjNodeList.Add(adjNode1);
        }
        if (adjNode2 != null)
        {
            adjNodeList.Add(adjNode2);
        }
        if (adjNode3 != null)
        {
            adjNodeList.Add(adjNode3);
        }
        if (adjNode4 != null)
        {
            adjNodeList.Add(adjNode4);
        }

    }
	
    

	// Update is called once per frame
	void Update () {

        foreach (GameObject g in adjNodeList)
        {
            Debug.DrawLine(transform.position, g.transform.position, Color.green);
        }
	
	}

    public void test()
    {

    }
}
