﻿using UnityEngine;
using System.Collections;

//add using System.Collections.Generic; to use the generic list format
using System.Collections.Generic;

public class Followers : Vehicle {

    public GameObject followerTarget;
    public GameObject previousTarget;

    public GameObject finalTarget;
    
    public GameObject ExitNode;

    public float nodeDist = 0;

    public float height = 1.7f;

	public GameObject crimeObj;

	public bool cop = false;

	public bool pursue = false;

	public bool criminal = false;

    private Vector3 force;
	private GameObject copTarget;


    // Use this for initialization
    override public void Start () {
        base.Start();

        ExitNode = GameObject.FindGameObjectWithTag("ExitNode");

        int NodeNum = Random.Range(0, gm.Nodes.Length);
        finalTarget = gm.Nodes[NodeNum];

		if (criminal == true) {
			NodeNum = Random.Range(0, gm.houses.Count);
			finalTarget = gm.houses[NodeNum];
		}

        followerTarget = GameObject.FindGameObjectWithTag("StartNode");
    }

    protected override void CalcSteeringForces()
    {
		if (cop == true) {
			foreach (var i in gm.criminals) {
				if (i == null) {
					gm.criminals.Remove(i);

				}

				else if((i.transform.position-transform.position).magnitude < copSight)
				{
					pursue = true;
					copTarget = i;

					bool added = false;
					foreach (var j in gm.copsAggro) {
						if (j == this.gameObject) {
							added = true;
						}
					}

					if (added == false) {
						gm.copsAggro.Add(this.gameObject);
					}

				}
			}

		}

		if (pursue == false) {
			//if you are at the node, find a new one
			if ((followerTarget.transform.position - transform.position).magnitude < nodeDist) {
				newNode ();
			}
			
			//resets y
			transform.position = new Vector3 (transform.position.x, height, transform.position.z);
			
			//debug to show target
			Debug.DrawLine (transform.position, followerTarget.transform.position);
			
			//reset value to (0, 0, 0)
			force = Vector3.zero;

			//calls and weights seek method
			force += Arrival (followerTarget.transform.position) * seekWeight;
			
			force += SeperationFollower () * sepWeight;
			
			//avoid obstacles
			for (int i = 0; i < gm.Obstacles.Length; i++) {
				force += AvoidObstacle (gm.Obstacles [i], safeDistance) * avoidWeight;
			}
			
			////avoid other followers
			//for (int i = 0; i < gm.followers.Count; i++)
			//{
			//    if (gm.followers[i].transform != transform)
			//    {
			//        force += AvoidObstacle(gm.followers[i], safeDistance) * avoidWeight;
			//    }
			//}
			
			
			//limits force to max force
			force = Vector3.ClampMagnitude (force, maxForce);
			
			//applied the steering force to this Vehicle's acceleration (ApplyForce)
			ApplyForce (force);
		} else {
			//float sMaxForce = maxForce;
			//float sMaxSpeed = maxSpeed;
			//maxForce = maxForce * 8;
			//maxSpeed = maxSpeed * 8;

			//resets y
			transform.position = new Vector3 (transform.position.x, height, transform.position.z);



			//reset value to (0, 0, 0)
			force = Vector3.zero;

			if (this.gameObject != gm.copsAggro[0]) {

				force += LeaderFollowing(gm.copsAggro[0]) * leaderWeight;
				//debug to show target
				Debug.DrawLine (transform.position, gm.copsAggro[0].transform.position);
			}else
			{//debug to show target
				Debug.DrawLine (transform.position, copTarget.transform.position);

				force += Seek(copTarget.transform.position) * seekWeight *4;
			}



			force += SeperationFollower() * sepWeight;

			force += AlignmentCop() * alignmentWeight;

			//avoid obstacles
			for (int i = 0; i < gm.Obstacles.Length; i++) {
				force += AvoidObstacle (gm.Obstacles [i], safeDistance) * avoidWeight;
			}

			//limits force to max force
			force = Vector3.ClampMagnitude (force, maxForce);
			
			//applied the steering force to this Vehicle's acceleration (ApplyForce)
			ApplyForce (force);

			if ((copTarget.transform.position-transform.position).magnitude < copDestroyRad)
			{
				gm.followers.Remove(copTarget);
				gm.criminals.Remove(copTarget);
				Object.Destroy(copTarget);


			}

			//maxForce = sMaxForce;
			//maxSpeed = sMaxSpeed;

			pursue = false;



			foreach (var i in gm.nodes) {
				float distToNode = Vector3.Distance(transform.position, followerTarget.transform.position);
				if(Vector3.Distance(i.transform.position, transform.position) < distToNode)
				{
					followerTarget = i;
					distToNode =Vector3.Distance(i.transform.position, transform.position);
					
				}
			}
		}
        
    }

    protected void newNode()
    {
        if ((finalTarget == followerTarget) && (finalTarget == ExitNode))
        {
            gm.followers.Remove(this.gameObject);
            Object.Destroy(this.gameObject);
        }

        if ((finalTarget == followerTarget))
        {
            finalTarget = ExitNode;
        }

        if (followerTarget.GetComponent<NodeScript>().adjSpecial == finalTarget)
        {
            previousTarget = followerTarget;
            followerTarget = followerTarget.GetComponent<NodeScript>().adjSpecial;
            return;
        }

        for (int i = 0; i < followerTarget.GetComponent<NodeScript>().adjNodeList.Count; i++)
        {
            if (followerTarget.GetComponent<NodeScript>().adjNodeList[i] == finalTarget)
            {
                previousTarget = followerTarget;
                followerTarget = followerTarget.GetComponent<NodeScript>().adjNodeList[i];
                return;
            }

        }

        int nextNodeNum = Random.Range(0, followerTarget.GetComponent<NodeScript>().adjNodeList.Count);

        if (followerTarget.GetComponent<NodeScript>().adjNodeList[nextNodeNum] != followerTarget && followerTarget.GetComponent<NodeScript>().adjNodeList[nextNodeNum] != previousTarget)
        {
            previousTarget = followerTarget;
            followerTarget = followerTarget.GetComponent<NodeScript>().adjNodeList[nextNodeNum];
            return;
        }
    }
}
