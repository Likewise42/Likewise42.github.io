﻿using UnityEngine;
using System.Collections;


//add using System.Collections.Generic; to use the generic list format
using System.Collections.Generic;

public class GameManager : MonoBehaviour {

    //-----------------------------------------------------------------------
    // Class Fields
    //-----------------------------------------------------------------------
    public GameObject dude;
    public GameObject target;

    public GameObject dudePrefab;
    public GameObject targetPrefab;
    public GameObject obstaclePrefab;
    public float targDist = 4f;

    private GameObject[] obstacles;

	public GameObject[]Obstacles {
		get { return obstacles; }
	}

	//flocking things
	private Vector3 centroid;
	public Vector3 Centroid{
		get { return centroid;}
	}

	private Vector3 flockDirection;
	public Vector3 FlockDirection{
		get {return flockDirection;}
	}

	private List<GameObject> flock;
	public List<GameObject> Flock {
		get	{ return flock;}
	}

	public int numberFlockers;

    //-----------------------------------------------------------------------
    // Start and Update
    //-----------------------------------------------------------------------
	void Start () {

		//create flock
		flock = new List<GameObject> ();

        //Create the target (noodle)
        Vector3 pos = new Vector3(0, 4.0f, 0);
        target = (GameObject)Instantiate(targetPrefab, pos, Quaternion.identity);
        //target = Instantiate(targetPrefab, pos, Quaternion.identity) as GameObject;

		for (int i = 0; i < numberFlockers; i++) {
			pos = new Vector3(Random.Range(-5,5), 1, Random.Range(-5,5));
			dude = (GameObject)Instantiate(dudePrefab, pos, Quaternion.identity);
			dude.GetComponent<Seeker> ().seekerTarget = target;
			flock.Add(dude);
		}

		//instantiates obstacles
		for (int i = 0; i < 20; i++) {
			pos = new Vector3(Random.Range(-30,30),1.1f,Random.Range(-30,30));
			Quaternion rot = Quaternion.Euler(new Vector3(0,Random.Range(0,180),0));
			Instantiate(obstaclePrefab, pos, rot);
		}

		//adds obstacles to array
		obstacles = GameObject.FindGameObjectsWithTag ("Obstacle");

        //set the camera's target 
        Camera.main.GetComponent<SmoothFollow>().target = transform;
        
	}
	

	void Update () {

		float dist = Vector3.Distance (target.transform.position, dude.transform.position);

		if (dist < targDist) {
			do{
			target.transform.position = new Vector3(Random.Range(-30,30), 4f, Random.Range (-30,30));
			}
			while (NearAnObstacle());
		}

		for (int i = 0; i < Flock.Count; i++) {
			dist = Vector3.Distance (target.transform.position, flock[i].transform.position);
			if (dist < 3.25f) {
				do{
					target.transform.position = new Vector3(Random.Range(-30,30), 4f, Random.Range (-30,30));
				}
				while (NearAnObstacle());
			}

            if (dist < targDist)
            {
                do
                {
                    target.transform.position = new Vector3(Random.Range(-30, 30), 4f, Random.Range(-30, 30));
                }
                while (NearAnObstacle());
            }
		}

        

        for (int i = 0; i < Flock.Count; i++)
        {
            flockDirection += Flock[i].transform.forward;
            centroid += Flock[i].transform.position;
        }
        flockDirection /= Flock.Count;
        centroid /= Flock.Count;

        transform.forward = flockDirection;
        transform.position = centroid;
	}

	bool NearAnObstacle()
	{

		//if the obstacle is withing 4 units of the noodle return true
		for (int i = 0; i < obstacles.Length; i++) {
			if (Vector3.Distance(target.transform.position,obstacles[i].transform.position) < 5f) {
				return true;
			}
		}

		//else false
		return false;
	}

    //-----------------------------------------------------------------------
    // Flocking Methods
    //-----------------------------------------------------------------------



}
