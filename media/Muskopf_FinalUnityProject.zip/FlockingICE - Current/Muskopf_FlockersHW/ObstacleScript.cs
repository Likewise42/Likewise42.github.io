﻿using UnityEngine;
using System.Collections;

public class ObstacleScript : MonoBehaviour {

	private float radius = 2.4f;

	public float Radius {
		get { return radius; }
	}
	
}

	